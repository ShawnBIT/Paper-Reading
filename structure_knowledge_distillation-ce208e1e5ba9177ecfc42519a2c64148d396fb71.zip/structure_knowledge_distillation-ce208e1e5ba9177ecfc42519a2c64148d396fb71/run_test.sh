
CUDA_VISIBLE_DEVICES='3' python3 test.py \
    --resume-from ./ckpt/CS_scenes_39326_0.75.pth \
	--data-dir '../cityscapes'




